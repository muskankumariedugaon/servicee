# FixNear – Local Technician Finder

React + Vite + Tailwind CSS + lucide-react.

## Installation
1. Node.js 18+ install karein (https://nodejs.org).
2. ZIP extract karein aur folder me jayein:
   ```bash
   cd fixnear
   npm install
   ```
## Run
```bash
npm run dev      # http://localhost:5173
npm run build    # production build -> dist/
npm run preview  # build preview
```
## Notes
- Data: `src/data/siteData.js` (services, FAQs, footer links).
- Hero image: `src/assets/technician.jpg` (replace to change).
- Current location browser Geolocation API se aati hai (localhost ya HTTPS par chalti hai).
