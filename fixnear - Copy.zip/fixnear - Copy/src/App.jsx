import { useState, useEffect, useMemo } from 'react'
import { ArrowRight, BadgeCheck, BatteryCharging, Car, CheckCircle2, Droplets, Hammer, HardHat, LayoutGrid, Lightbulb, Loader2, LocateFixed, MapPin, Menu, MessageSquareText, PaintRoller, Refrigerator, Search, SearchX, Settings, ShieldCheck, Snowflake, Star, WashingMachine, Wrench, X } from 'lucide-react'
import logo from './assets/logo.png'
import technician from './assets/technician.png'

const navLinks = [
  { label: 'Home', href: '#home' },
  { label: 'Services', href: '#services' },
  { label: 'How It Works', href: '#how-it-works' },
  { label: 'About', href: '#guidance' },
]

const categories = [
  { id: 'all', label: 'All services' },
  { id: 'appliance', label: 'Appliance repair' },
  { id: 'home', label: 'Home repairs' },
  { id: 'power', label: 'Power & water' },
]

const services = [
  { id: 1, title: 'AC Repair', category: 'appliance', icon: Snowflake, desc: 'Cooling & maintenance', tags: 'Not cooling · Water leakage' },
  { id: 2, title: 'Electrician', category: 'power', icon: Lightbulb, desc: 'Wiring & electrical repairs', tags: 'Switches · Fans · Wiring' },
  { id: 3, title: 'Plumber', category: 'power', icon: Wrench, desc: 'Leaks & pipe repairs', tags: 'Leaking taps · Blocked drains' },
  { id: 4, title: 'Refrigerator', category: 'appliance', icon: Refrigerator, desc: 'Cooling & fridge repairs', tags: 'Not cooling · Unusual noise' },
  { id: 5, title: 'Washing Machine', category: 'appliance', icon: WashingMachine, desc: 'Wash & spin repairs', tags: 'Not spinning · Drainage issues' },
  { id: 6, title: 'Inverter & Solar', category: 'power', icon: BatteryCharging, desc: 'Power backup & battery care', tags: 'No backup · Charging issues' },
  { id: 7, title: 'Carpenter', category: 'home', icon: Hammer, desc: 'Furniture & woodwork', tags: 'Doors · Hinges · Furniture repairs' },
  { id: 8, title: 'RO Repair', category: 'appliance', icon: Droplets, desc: 'Filters & purifier servicing', tags: 'Low water flow · Filter care' },
  { id: 9, title: 'Appliance Repair', category: 'appliance', icon: Settings, desc: 'Expert repair and servicing for your home appliances, microwaves, geysers, and more.', tags: '' },
  { id: 10, title: 'Painting', category: 'home', icon: PaintRoller, desc: 'Refresh your walls with professional painting, putty, crack repair, and wall finishing services.', tags: '' },
  { id: 11, title: 'Vehicle Repair', category: 'home', icon: Car, desc: 'Get reliable repair and maintenance services for bikes, scooters, cars, and electric vehicles at your doorstep.', tags: '' },
  { id: 12, title: 'Construction', category: 'home', icon: HardHat, desc: 'Find skilled professionals for masonry, tile fitting, plastering, flooring, and home renovation projects.', tags: '' },
]

const steps = [
  { id: 1, title: 'Choose a service', desc: 'Select the type of technician you need.', icon: LayoutGrid },
  { id: 2, title: 'Tell us your problem', desc: 'Describe the issue so we can understand what needs fixing.', icon: MessageSquareText },
  { id: 3, title: 'Get a technician', desc: 'Find an available professional near your location.', icon: ShieldCheck },
  { id: 4, title: 'Get it fixed', desc: 'Get the help you need to resolve the problem.', icon: BadgeCheck },
]

const faqs = [
  { q: 'Not sure which service to choose?', a: 'Start with the appliance or part of your home that needs attention. For example, choose Plumber for a leaking tap or Electrician for a faulty switch. Describe the symptoms when you request help.' },
  { q: 'How do I find technicians in my area?', a: 'Enter your area or PIN code, or allow your current location. Then choose a service to explore technicians near you. Availability can vary by service and location.' },
  { q: 'What should I share before a visit?', a: 'Mention what is not working, when the issue started and the appliance brand or model, if relevant. Discuss the scope of work and any visit or repair charges directly with the technician.' },
]

const footerColumns = [
  { title: 'Services', links: ['Electrician', 'Plumber', 'AC Repair', 'Refrigerator', 'View all'] },
  { title: 'Company', links: ['About', 'How it works', 'Become a technician', 'Contact'] },
  { title: 'Support', links: ['Help Center', 'Privacy', 'Terms', 'Safety'] },
]

function Navbar() {
  const [open, setOpen] = useState(false)
  const [active, setActive] = useState('#home')

  // Scroll ke saath current section highlight hota hai
  useEffect(() => {
    const onScroll = () => {
      const y = window.scrollY + 120
      let cur = navLinks[0].href
      navLinks.forEach((l) => {
        const el = document.querySelector(l.href)
        if (el && el.offsetTop <= y) cur = l.href
      })
      setActive(cur)
    }
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  const go = (href) => { setActive(href); setOpen(false) }

  return (
    <header className="sticky top-0 z-50 border-b border-[#E8DFCF] bg-[#F6F1E7]/95 backdrop-blur">
      <nav className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-3 px-4 sm:h-[72px] sm:px-6">
        <a href="#home" onClick={() => go('#home')} className="flex shrink-0 items-center" aria-label="FixNear home">
          <img src={logo} alt="FixNear" className="h-9 w-auto sm:h-11" />
        </a>

        <ul className="hidden items-center gap-6 md:flex lg:gap-8">
          {navLinks.map((l) => (
            <li key={l.href}>
              <a href={l.href} onClick={() => go(l.href)}
                className={`text-sm transition-colors hover:text-[#C8603A] ${active === l.href ? 'font-semibold text-[#1F4A38] underline decoration-[#C8603A] decoration-2 underline-offset-8' : 'font-medium text-[#1F4A38]/80'}`}>
                {l.label}
              </a>
            </li>
          ))}
        </ul>

        <div className="hidden items-center gap-4 md:flex">
          <a href="#" className="text-sm font-medium text-[#1F4A38] hover:text-[#C8603A]">Become Tech</a>
          <a href="#" className="text-sm font-medium text-[#1F4A38] hover:text-[#C8603A]">Login</a>
          <a href="#" className="rounded-lg bg-[#1F4A38] px-4 py-2 text-sm font-semibold text-white transition hover:bg-[#173a2c]">Sign Up</a>
        </div>

        <button aria-label="Toggle menu" aria-expanded={open} onClick={() => setOpen(!open)}
          className="rounded-lg p-2 text-[#1F4A38] hover:bg-[#D9C7A9]/40 md:hidden">
          {open ? <X size={24} /> : <Menu size={24} />}
        </button>
      </nav>

      {open && (
        <div className="border-t border-[#E8DFCF] bg-[#F6F1E7] px-4 pb-5 pt-3 md:hidden">
          <ul className="flex flex-col">
            {navLinks.map((l) => (
              <li key={l.href}>
                <a href={l.href} onClick={() => go(l.href)}
                  className={`block rounded-lg px-3 py-3 text-sm text-[#1F4A38] hover:bg-[#D9C7A9]/40 ${active === l.href ? 'bg-[#D9C7A9]/40 font-semibold' : 'font-medium'}`}>
                  {l.label}
                </a>
              </li>
            ))}
            <li><a href="#" className="block rounded-lg px-3 py-3 text-sm font-medium text-[#1F4A38] hover:bg-[#D9C7A9]/40">Become Tech</a></li>
          </ul>
          <div className="mt-3 flex gap-3">
            <a href="#" className="flex-1 rounded-lg border border-[#1F4A38] py-2.5 text-center text-sm font-semibold text-[#1F4A38]">Login</a>
            <a href="#" className="flex-1 rounded-lg bg-[#1F4A38] py-2.5 text-center text-sm font-semibold text-white">Sign Up</a>
          </div>
        </div>
      )}
    </header>
  )
}

function Hero({ onSearch }) {
  const [query, setQuery] = useState('')
  const [manual, setManual] = useState('')
  const [showManual, setShowManual] = useState(false)
  const [locLabel, setLocLabel] = useState('Use my current location')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const allowLocation = () => {
    setError('')
    if (!('geolocation' in navigator)) { setError('Location is not supported in this browser.'); return }
    setLoading(true)
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setLocLabel(`Location set (${pos.coords.latitude.toFixed(3)}, ${pos.coords.longitude.toFixed(3)})`)
        setLoading(false)
      },
      (err) => {
        setLoading(false)
        setError(err.code === 1 ? 'Location permission denied. Enter your area manually.' : 'Could not get your location. Try again.')
        setShowManual(true)
      },
      { enableHighAccuracy: true, timeout: 10000 }
    )
  }

  const submit = (e) => {
    e.preventDefault()
    onSearch(query.trim())
    document.getElementById('services')?.scrollIntoView({ behavior: 'smooth' })
  }

  return (
    <section id="home" className="mx-auto grid max-w-6xl grid-cols-1 items-center gap-10 px-4 py-10 sm:px-6 md:py-16 lg:grid-cols-2">
      <div className="min-w-0">
        <span className="inline-flex items-center gap-2 rounded-full bg-[#D9C7A9] px-3 py-1 text-xs font-medium text-[#1F4A38]">
          <span className="h-1.5 w-1.5 rounded-full bg-[#1F4A38]" /> Trusted local technicians
        </span>
        <h1 className="mt-5 text-3xl font-bold leading-tight text-[#1F4A38] min-[400px]:text-4xl sm:text-5xl">
          Everyday repairs.<br /><span className="text-[#C8603A]">The right expert nearby.</span>
        </h1>
        <p className="mt-4 max-w-md text-sm text-[#1F4A38]/70 sm:text-base">
          Electrician, plumber, AC, refrigerator, inverter and more — find available technicians near your location.
        </p>

        <form onSubmit={submit} className="mt-8 max-w-md rounded-2xl border border-[#E8DFCF] bg-[#FBF8F2] p-4 shadow-lg sm:p-5">
          <h2 className="text-base font-semibold text-[#1F4A38]">What service do you need?</h2>
          <label className="mt-3 flex items-center gap-2 rounded-xl border border-[#E8DFCF] bg-white px-3 py-3">
            <Search size={16} className="text-[#1F4A38]/60" />
            <input value={query} onChange={(e) => setQuery(e.target.value)} type="text"
              placeholder="Search Electrician, AC repair, Plumber..."
              className="w-full bg-transparent text-sm outline-none placeholder:text-[#1F4A38]/40" />
          </label>

          <div className="mt-3 flex items-center justify-between gap-2 rounded-xl border border-[#E8DFCF] bg-white px-3 py-3">
            <span className="flex min-w-0 items-center gap-2 text-sm font-medium">
              <MapPin size={16} className="shrink-0" /> <span className="truncate">{locLabel}</span>
            </span>
            <button type="button" onClick={allowLocation} disabled={loading}
              className="flex shrink-0 items-center gap-1 text-sm font-medium hover:text-[#C8603A]">
              {loading ? <Loader2 size={15} className="animate-spin" /> : <LocateFixed size={15} />} Allow
            </button>
          </div>
          {error && <p className="mt-2 text-xs text-[#C8603A]">{error}</p>}

          <button type="button" onClick={() => setShowManual(!showManual)}
            className="mt-2 flex items-center gap-1 text-xs text-[#1F4A38]/70 hover:text-[#1F4A38]">
            <MapPin size={12} /> Enter Your location manually
          </button>
          {showManual && (
            <input value={manual} onChange={(e) => setManual(e.target.value)} type="text" placeholder="Area or PIN code"
              className="mt-2 w-full rounded-xl border border-[#E8DFCF] bg-white px-3 py-2.5 text-sm outline-none" />
          )}

          <button type="submit"
            className="mt-3 flex w-full items-center justify-center gap-2 rounded-xl bg-[#1F4A38] py-3 text-sm font-semibold text-white transition hover:bg-[#173a2c]">
            Find a Technician <ArrowRight size={16} />
          </button>

          <ul className="mt-3 flex flex-wrap gap-x-4 gap-y-1 text-[11px] text-[#1F4A38]/80">
            {['Verified technicians', 'Nearby professionals', 'Fast response'].map((t) => (
              <li key={t} className="flex items-center gap-1"><CheckCircle2 size={13} className="text-[#1F4A38]" /> {t}</li>
            ))}
          </ul>
        </form>
      </div>

      <div className="relative mx-auto w-full min-w-0 max-w-lg lg:max-w-none">
        <img src={technician} alt="FixNear technician holding a drill with toolbox"
          className="aspect-[1098/800] w-full object-contain" />
        <div className="absolute left-2 top-4 rounded-xl border border-[#E8DFCF] bg-[#FBF8F2] px-3 py-2 shadow-md sm:-left-4 sm:top-8">
          <p className="flex items-center gap-1.5 text-xs font-semibold"><span className="h-1.5 w-1.5 rounded-full bg-[#1F4A38]" /> Available</p>
          <p className="text-[11px] text-[#1F4A38]/70">Technician nearby</p>
          <p className="text-[11px] text-[#1F4A38]/70">1.8 km away</p>
        </div>
        {/* <div className="absolute right-2 top-2 rounded-xl border border-[#E8DFCF] bg-[#FBF8F2] px-3 py-2 shadow-md sm:-top-5 sm:right-4">
          <p className="flex items-center gap-1 text-sm font-bold"><Star size={14} className="fill-[#C8603A] text-[#C8603A]" /> 4.8</p>
          <p className="text-[11px] text-[#1F4A38]/70">120+ jobs completed</p>
        </div> */}   

    
        <div className="absolute bottom-5 left-2 sm:bottom-5 sm:left-4 rounded-lg border border-[#E8DFCF] bg-[#FBF8F2] px-2.5 py-1.5 shadow-md">
          <p className="flex items-center gap-1 text-xs font-bold leading-4">
            <Star size={12} className="fill-[#C8603A] text-[#C8603A]" />
            4.8
          </p>
          <p className="text-[10px] leading-4 text-[#1F4A38]/70">120+ jobs completed</p>
        </div> 


        <div className="absolute bottom-4 right-2 flex items-center gap-2 rounded-xl border border-[#E8DFCF] bg-[#FBF8F2] px-3 py-2 shadow-md sm:right-4">
          <ShieldCheck size={18} className="text-[#1F4A38]" />
          <div><p className="text-xs font-semibold">Verified</p><p className="text-[11px] text-[#1F4A38]/70">Professional</p></div>
        </div>
      </div>
    </section>
  )
}

function Services({ externalQuery = '' }) {
  const [active, setActive] = useState('all')
  const [query, setQuery] = useState('')

  // Hero search se aayi query sync karo
  useEffect(() => { setQuery(externalQuery); if (externalQuery) setActive('all') }, [externalQuery])

  const filtered = useMemo(() => {
    const q = query.toLowerCase()
    return services.filter((s) =>
      (active === 'all' || s.category === active) &&
      (!q || `${s.title} ${s.desc} ${s.tags}`.toLowerCase().includes(q)))
  }, [active, query])

  return (
    <section id="services" className="mx-auto max-w-6xl px-4 py-10 sm:px-6 md:py-14">
      <h2 className="text-2xl font-bold text-[#1F4A38] sm:text-3xl">What can we help you with?</h2>
      <p className="mt-2 text-sm text-[#1F4A38]/70">Choose a service to find the right professional nearby.</p>

      <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:items-center">
        <div className="-mx-4 flex gap-2 overflow-x-auto px-4 pb-1 sm:mx-0 sm:flex-wrap sm:overflow-visible sm:px-0 sm:pb-0">
        {categories.map((c) => (
          <button key={c.id} onClick={() => setActive(c.id)}
            className={`shrink-0 whitespace-nowrap rounded-full border px-4 py-2 text-xs font-medium transition ${active === c.id ? 'border-[#1F4A38] bg-[#1F4A38] text-white' : 'border-[#E8DFCF] bg-[#FBF8F2] text-[#1F4A38] hover:border-[#1F4A38]'}`}>
            {c.label}
          </button>
        ))}
        </div>
        <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search services..."
          className="w-full w-full rounded-full border border-[#E8DFCF] bg-[#FBF8F2] px-4 py-2 text-sm outline-none focus:border-[#1F4A38] sm:ml-auto sm:w-56 sm:text-xs" />
      </div>

      {filtered.length ? (
        <div className="mt-6 grid grid-cols-1 gap-4 min-[480px]:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {filtered.map(({ id, title, icon: Icon, desc, tags }) => (
            <article key={id} className="flex flex-col rounded-2xl border border-[#E8DFCF] bg-[#FBF8F2] p-5 transition hover:shadow-md">
              <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-[#D9C7A9]"><Icon size={18} /></span>
              <h3 className="mt-4 text-base font-semibold text-[#1F4A38]">{title}</h3>
              <p className="mt-1 text-xs leading-relaxed text-[#1F4A38]/70">{desc}</p>
              {tags && <p className="text-xs text-[#1F4A38]/70">{tags}</p>}
              <a href="#home" className="mt-auto flex items-center gap-1 pt-4 text-xs font-medium text-[#1F4A38] hover:text-[#C8603A]">
                Find technician <ArrowRight size={13} />
              </a>
            </article>
          ))}
        </div>
      ) : (
        <div className="mt-8 flex flex-col items-center rounded-2xl border border-dashed border-[#E8DFCF] py-12 text-center">
          <SearchX size={28} className="text-[#1F4A38]/50" />
          <p className="mt-3 text-sm font-medium">No service found for “{query}”.</p>
          <button onClick={() => { setQuery(''); setActive('all') }} className="mt-2 text-xs font-medium text-[#C8603A] underline">Clear filters</button>
        </div>
      )}

      <p className="mt-6 flex items-center gap-2 text-xs text-[#1F4A38]/70">
        <MapPin size={13} /> Technician availability depends on your location. Add your area to find nearby help.
      </p>
    </section>
  )
}

function HowItWorks() {
  return (
    <section id="how-it-works" className="bg-[#D9C7A9] py-12 md:py-16">
      <div className="mx-auto max-w-6xl px-4 sm:px-6">
        <h2 className="text-2xl font-bold text-[#1F4A38] sm:text-3xl">How FixNear works</h2>
        <p className="mt-2 text-sm text-[#1F4A38]/70">Get the help you need in four simple steps.</p>
        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {steps.map(({ id, title, desc, icon: Icon }) => (
            <div key={id} className="rounded-2xl border border-[#E8DFCF] bg-[#FBF8F2] p-5">
              <span className="flex h-7 w-7 items-center justify-center rounded-full bg-[#1F4A38] text-xs font-semibold text-white">0{id}</span>
              <Icon size={20} className="mt-4 text-[#1F4A38]" />
              <h3 className="mt-2 text-base font-semibold text-[#1F4A38]">{title}</h3>
              <p className="mt-1 text-xs leading-relaxed text-[#1F4A38]/70">{desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

function Guidance() {
  return (
    <section id="guidance" className="mx-auto grid max-w-6xl gap-10 px-4 py-12 sm:px-6 md:py-16 lg:grid-cols-[1fr_2fr]">
      <div>
        <h2 className="text-2xl font-bold leading-tight text-[#1F4A38] sm:text-3xl">A little guidance,<br />before you start.</h2>
        <p className="mt-3 text-sm text-[#1F4A38]/70">Useful things to know when looking for help with your home.</p>
        <a href="#" className="mt-4 inline-flex items-center gap-1 text-sm font-medium text-[#1F4A38] hover:text-[#C8603A]">
          Visit Help Center <ArrowRight size={14} />
        </a>
      </div>
      <div className="divide-y divide-[#E8DFCF] border-b border-[#E8DFCF]">
        {faqs.map(({ q, a }) => (
          <div key={q} className="py-5 first:pt-0">
            <h3 className="text-base font-semibold text-[#1F4A38]">{q}</h3>
            <p className="mt-2 text-sm leading-relaxed text-[#1F4A38]/70">{a}</p>
          </div>
        ))}
      </div>
    </section>
  )
}

function Footer() {
  return (
    <footer className="border-t border-[#E8DFCF]">
      <div className="mx-auto max-w-6xl px-4 py-12 sm:px-6">
        <div className="grid grid-cols-2 gap-8 lg:grid-cols-4">
          <div className="col-span-2 lg:col-span-1">
            <img src={logo} alt="FixNear" className="h-10 w-auto" />
            <p className="mt-2 max-w-[220px] text-xs text-[#1F4A38]/70">Find trusted technicians near you.</p>
          </div>
          {footerColumns.map((col) => (
            <div key={col.title}>
              <h4 className="text-sm font-semibold text-[#1F4A38]">{col.title}</h4>
              <ul className="mt-3 space-y-2">
                {col.links.map((l) => (
                  <li key={l}><a href="#" className="text-xs text-[#1F4A38]/70 hover:text-[#C8603A]">{l}</a></li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        <p className="mt-10 border-t border-[#E8DFCF] pt-6 text-center text-[11px] text-[#1F4A38]/70">© 2026 FixNear. All rights reserved.</p>
      </div>
    </footer>
  )
}

export default function App() {
  // Hero se selected search query Services section ko pass hoti hai
  const [query, setQuery] = useState('')
  return (
    <div className="min-h-screen overflow-x-hidden bg-[#F6F1E7] text-[#1F4A38]">
      <Navbar />
      <main>
        <Hero onSearch={setQuery} />
        <Services externalQuery={query} />
        <HowItWorks />
        <Guidance />
      </main>
      <Footer />
    </div>
  )
}
